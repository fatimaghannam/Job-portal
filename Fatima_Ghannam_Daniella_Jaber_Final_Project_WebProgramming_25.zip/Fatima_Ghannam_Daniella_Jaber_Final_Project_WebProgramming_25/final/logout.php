<?php
header("Location: final.html");
exit();
?>
